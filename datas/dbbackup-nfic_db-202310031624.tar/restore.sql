--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.8
-- Dumped by pg_dump version 14.8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE nfic_db;
--
-- Name: nfic_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE nfic_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE nfic_db OWNER TO postgres;

\connect nfic_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: adjust_stocks_from_sales(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.adjust_stocks_from_sales() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
   
        INSERT INTO stock_transactions (product_id, quantity, transaction_type,new_stocks)
        VALUES (NEW.product_id, NEW.quantity, 'SALES',(select 
    (p.initial_stocks + (select coalesce(sum(po.output_quantity),0) as in from production_outputs po where po.product_id = p.product_id) -
    (select coalesce(sum(si.quantity), 0) as out from sales_items si where si.product_id = p.product_id) - 
     (select coalesce(sum(rp.quantity), 0) as repros from repro_products rp where rp.product_id = p.product_id)) as current_stocks
    from products p where p.product_id = new.product_id limit 1));

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.adjust_stocks_from_sales() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customer_id integer NOT NULL,
    customer_name character varying NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customer_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.customers_customer_id_seq OWNER TO postgres;

--
-- Name: customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customer_id_seq OWNED BY public.customers.customer_id;


--
-- Name: delivered_packagings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delivered_packagings (
    id bigint NOT NULL,
    packaging_id integer NOT NULL,
    delivered_quantity integer NOT NULL,
    date_delivered character varying NOT NULL
);


ALTER TABLE public.delivered_packagings OWNER TO postgres;

--
-- Name: delivered_packagings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delivered_packagings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.delivered_packagings_id_seq OWNER TO postgres;

--
-- Name: delivered_packagings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delivered_packagings_id_seq OWNED BY public.delivered_packagings.id;


--
-- Name: packaging_adjustments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packaging_adjustments (
    id integer NOT NULL,
    packaging_id integer NOT NULL,
    adjustment_value integer NOT NULL,
    date_adjusted character varying,
    reason_for_adjustment character varying
);


ALTER TABLE public.packaging_adjustments OWNER TO postgres;

--
-- Name: packaging_adjustments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packaging_adjustments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.packaging_adjustments_id_seq OWNER TO postgres;

--
-- Name: packaging_adjustments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packaging_adjustments_id_seq OWNED BY public.packaging_adjustments.id;


--
-- Name: packagings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.packagings (
    packaging_id bigint NOT NULL,
    packaging_name character varying,
    initial_stocks bigint
);


ALTER TABLE public.packagings OWNER TO postgres;

--
-- Name: packagings_packaging_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.packagings_packaging_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.packagings_packaging_id_seq OWNER TO postgres;

--
-- Name: packagings_packaging_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.packagings_packaging_id_seq OWNED BY public.packagings.packaging_id;


--
-- Name: product_sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.product_sales (
    customer_name character varying,
    "createdAt" character varying,
    sales_id bigint NOT NULL,
    "updatedAt" character varying,
    customer_id integer
);


ALTER TABLE public.product_sales OWNER TO postgres;

--
-- Name: product_sales_sales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.product_sales_sales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.product_sales_sales_id_seq OWNER TO postgres;

--
-- Name: product_sales_sales_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.product_sales_sales_id_seq OWNED BY public.product_sales.sales_id;


--
-- Name: production_outputs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.production_outputs (
    production_id bigint NOT NULL,
    product_id integer NOT NULL,
    output_quantity integer NOT NULL,
    damaged_packaging integer,
    production_date date NOT NULL
);


ALTER TABLE public.production_outputs OWNER TO postgres;

--
-- Name: production_outputs_production_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.production_outputs_production_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.production_outputs_production_id_seq OWNER TO postgres;

--
-- Name: production_outputs_production_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.production_outputs_production_id_seq OWNED BY public.production_outputs.production_id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.products (
    product_id integer NOT NULL,
    product_name character varying,
    initial_stocks integer NOT NULL,
    packaging_size numeric
);


ALTER TABLE public.products OWNER TO postgres;

--
-- Name: products_product_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.products_product_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.products_product_id_seq OWNER TO postgres;

--
-- Name: products_product_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.products_product_id_seq OWNED BY public.products.product_id;


--
-- Name: released_packagings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.released_packagings (
    id bigint NOT NULL,
    packaging_id bigint NOT NULL,
    quantity_released bigint NOT NULL,
    date_released character varying,
    released_for character varying
);


ALTER TABLE public.released_packagings OWNER TO postgres;

--
-- Name: released_packagings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.released_packagings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.released_packagings_id_seq OWNER TO postgres;

--
-- Name: released_packagings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.released_packagings_id_seq OWNED BY public.released_packagings.id;


--
-- Name: repro_products; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.repro_products (
    id bigint NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    reason character varying,
    date_reprod date DEFAULT now()
);


ALTER TABLE public.repro_products OWNER TO postgres;

--
-- Name: repro_products_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.repro_products_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.repro_products_id_seq OWNER TO postgres;

--
-- Name: repro_products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.repro_products_id_seq OWNED BY public.repro_products.id;


--
-- Name: returned_packagings; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.returned_packagings (
    id bigint NOT NULL,
    packaging_id integer NOT NULL,
    quantity_returned integer NOT NULL,
    returned_date character varying NOT NULL
);


ALTER TABLE public.returned_packagings OWNER TO postgres;

--
-- Name: returned_packagings_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.returned_packagings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.returned_packagings_id_seq OWNER TO postgres;

--
-- Name: returned_packagings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.returned_packagings_id_seq OWNED BY public.returned_packagings.id;


--
-- Name: sales_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_items (
    sales_id integer NOT NULL,
    product_id integer NOT NULL,
    quantity integer NOT NULL,
    sales_item_id bigint NOT NULL
);


ALTER TABLE public.sales_items OWNER TO postgres;

--
-- Name: sales_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.sales_items_id_seq OWNER TO postgres;

--
-- Name: sales_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_items_id_seq OWNED BY public.sales_items.sales_item_id;


--
-- Name: customers customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN customer_id SET DEFAULT nextval('public.customers_customer_id_seq'::regclass);


--
-- Name: delivered_packagings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivered_packagings ALTER COLUMN id SET DEFAULT nextval('public.delivered_packagings_id_seq'::regclass);


--
-- Name: packaging_adjustments id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packaging_adjustments ALTER COLUMN id SET DEFAULT nextval('public.packaging_adjustments_id_seq'::regclass);


--
-- Name: packagings packaging_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packagings ALTER COLUMN packaging_id SET DEFAULT nextval('public.packagings_packaging_id_seq'::regclass);


--
-- Name: product_sales sales_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales ALTER COLUMN sales_id SET DEFAULT nextval('public.product_sales_sales_id_seq'::regclass);


--
-- Name: production_outputs production_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_outputs ALTER COLUMN production_id SET DEFAULT nextval('public.production_outputs_production_id_seq'::regclass);


--
-- Name: products product_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products ALTER COLUMN product_id SET DEFAULT nextval('public.products_product_id_seq'::regclass);


--
-- Name: released_packagings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.released_packagings ALTER COLUMN id SET DEFAULT nextval('public.released_packagings_id_seq'::regclass);


--
-- Name: repro_products id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repro_products ALTER COLUMN id SET DEFAULT nextval('public.repro_products_id_seq'::regclass);


--
-- Name: returned_packagings id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.returned_packagings ALTER COLUMN id SET DEFAULT nextval('public.returned_packagings_id_seq'::regclass);


--
-- Name: sales_items sales_item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items ALTER COLUMN sales_item_id SET DEFAULT nextval('public.sales_items_id_seq'::regclass);


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3416.dat

--
-- Data for Name: delivered_packagings; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3397.dat

--
-- Data for Name: packaging_adjustments; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3418.dat

--
-- Data for Name: packagings; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3399.dat

--
-- Data for Name: product_sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3401.dat

--
-- Data for Name: production_outputs; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3403.dat

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3405.dat

--
-- Data for Name: released_packagings; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3407.dat

--
-- Data for Name: repro_products; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3409.dat

--
-- Data for Name: returned_packagings; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3411.dat

--
-- Data for Name: sales_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

\i $$PATH$$/3413.dat

--
-- Name: customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customer_id_seq', 15, true);


--
-- Name: delivered_packagings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delivered_packagings_id_seq', 7, true);


--
-- Name: packaging_adjustments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packaging_adjustments_id_seq', 1, false);


--
-- Name: packagings_packaging_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.packagings_packaging_id_seq', 14, true);


--
-- Name: product_sales_sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.product_sales_sales_id_seq', 602, true);


--
-- Name: production_outputs_production_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.production_outputs_production_id_seq', 156, true);


--
-- Name: products_product_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.products_product_id_seq', 29, true);


--
-- Name: released_packagings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.released_packagings_id_seq', 68, true);


--
-- Name: repro_products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.repro_products_id_seq', 21, true);


--
-- Name: returned_packagings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.returned_packagings_id_seq', 15, true);


--
-- Name: sales_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_items_id_seq', 1016, true);


--
-- Name: customers customers_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pk PRIMARY KEY (customer_id);


--
-- Name: delivered_packagings delivered_packagings_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivered_packagings
    ADD CONSTRAINT delivered_packagings_pk PRIMARY KEY (id);


--
-- Name: packagings packagings_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packagings
    ADD CONSTRAINT packagings_pk PRIMARY KEY (packaging_id);


--
-- Name: product_sales product_sales_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_pk PRIMARY KEY (sales_id);


--
-- Name: production_outputs production_outputs_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_outputs
    ADD CONSTRAINT production_outputs_pk PRIMARY KEY (production_id);


--
-- Name: products products_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pk PRIMARY KEY (product_id);


--
-- Name: released_packagings released_packagings_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.released_packagings
    ADD CONSTRAINT released_packagings_pk PRIMARY KEY (id);


--
-- Name: repro_products repro_products_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repro_products
    ADD CONSTRAINT repro_products_pk PRIMARY KEY (id);


--
-- Name: returned_packagings returned_packagings_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.returned_packagings
    ADD CONSTRAINT returned_packagings_pk PRIMARY KEY (id);


--
-- Name: sales_items sales_items_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_pk PRIMARY KEY (sales_item_id);


--
-- Name: packaging_adjustments_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX packaging_adjustments_id_idx ON public.packaging_adjustments USING btree (id);


--
-- Name: packagings_packaging_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX packagings_packaging_id_idx ON public.packagings USING btree (packaging_id);


--
-- Name: delivered_packagings delivered_packagings_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delivered_packagings
    ADD CONSTRAINT delivered_packagings_fk FOREIGN KEY (packaging_id) REFERENCES public.packagings(packaging_id) ON DELETE CASCADE;


--
-- Name: packaging_adjustments packaging_adjustments_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.packaging_adjustments
    ADD CONSTRAINT packaging_adjustments_fk FOREIGN KEY (packaging_id) REFERENCES public.packagings(packaging_id) ON DELETE CASCADE;


--
-- Name: product_sales product_sales_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.product_sales
    ADD CONSTRAINT product_sales_fk FOREIGN KEY (customer_id) REFERENCES public.customers(customer_id);


--
-- Name: production_outputs production_outputs_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.production_outputs
    ADD CONSTRAINT production_outputs_fk FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: released_packagings released_packagings_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.released_packagings
    ADD CONSTRAINT released_packagings_fk FOREIGN KEY (packaging_id) REFERENCES public.packagings(packaging_id) ON DELETE CASCADE;


--
-- Name: repro_products repro_products_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.repro_products
    ADD CONSTRAINT repro_products_fk FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- Name: returned_packagings returned_packagings_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.returned_packagings
    ADD CONSTRAINT returned_packagings_fk FOREIGN KEY (packaging_id) REFERENCES public.packagings(packaging_id) ON DELETE CASCADE;


--
-- Name: sales_items sales_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_fk FOREIGN KEY (sales_id) REFERENCES public.product_sales(sales_id) ON DELETE CASCADE;


--
-- Name: sales_items sales_items_fk_1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_fk_1 FOREIGN KEY (product_id) REFERENCES public.products(product_id);


--
-- PostgreSQL database dump complete
--

